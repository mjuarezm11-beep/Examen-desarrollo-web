<?php


date_default_timezone_set('America/Guatemala');

const LIMITE_SUBSIDIO = 100; 

const COMBUSTIBLES = [
    'Super' => ['subsidio' => 32.82, 'sin' => 37.82],
    'Regular'  => ['subsidio' => 31.57, 'sin' => 36.57],
    'Diésel'   => ['subsidio' => 29.75, 'sin' => 36.75],
];

$archivo = __DIR__ . '/data/ventas.txt';
if (!is_dir(dirname($archivo))) {
    mkdir(dirname($archivo), 0777, true);
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'] ?? 'registrar';

    if ($accion === 'limpiar') {
        file_put_contents($archivo, '', LOCK_EX);
        header('Location: index.php?ok=limpio');
        exit;
    }

    $tipo    = $_POST['tipo'] ?? '';
    $galones = str_replace(',', '.', trim($_POST['galones'] ?? ''));

    if (!array_key_exists($tipo, COMBUSTIBLES)) {
        $error = 'Seleccione un tipo de combustible válido.';
    } elseif (!is_numeric($galones) || (float)$galones <= 0) {
        $error = 'Ingrese una cantidad de galones mayor que 0.';
    } else {
        $galones = round((float)$galones, 2);

       
        if ($galones > LIMITE_SUBSIDIO) {
            $precio   = COMBUSTIBLES[$tipo]['sin'];
            $subsidio = 'NO';
        } else {
            $precio   = COMBUSTIBLES[$tipo]['subsidio'];
            $subsidio = 'SI';
        }

        $total = round($galones * $precio, 2);
        $linea = implode('|', [
            date('Y-m-d H:i:s'), $tipo, $galones, $precio, $subsidio, $total
        ]) . PHP_EOL;

        file_put_contents($archivo, $linea, FILE_APPEND | LOCK_EX);
        header('Location: index.php?ok=registrado');
        exit;
    }
}

$hoy    = date('Y-m-d');
$ventas = [];
$lineas = file_exists($archivo)
    ? file($archivo, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES)
    : [];

foreach ($lineas as $linea) {
    $c = explode('|', $linea);
    if (count($c) === 6 && strpos($c[0], $hoy) === 0) {
        $ventas[] = [
            'fecha'    => $c[0],
            'tipo'     => $c[1],
            'galones'  => (float)$c[2],
            'precio'   => (float)$c[3],
            'subsidio' => $c[4],
            'total'    => (float)$c[5],
        ];
    }
}


$totalesPorTipo = array_fill_keys(array_keys(COMBUSTIBLES), 0.0);
$totalGeneral   = 0.0;
$conSubsidio    = 0; // 

foreach ($ventas as $v) {
    $totalesPorTipo[$v['tipo']] += $v['total'];
    $totalGeneral += $v['total'];
    if ($v['subsidio'] === 'SI') {
        $conSubsidio++;
    }
}

function q(float $n): string
{
    return 'Q' . number_format($n, 2);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Control de Combustible</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<main class="contenedor">
    <h1>Control de Combustible</h1>

    <?php if (($_GET['ok'] ?? '') === 'registrado'): ?>
     
    <?php elseif (($_GET['ok'] ?? '') === 'limpio'): ?>
        <p class="mensaje exito">Registros eliminados.</p>
    <?php endif; ?>
    <?php if ($error): ?>
        <p class="mensaje error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <section class="tarjeta">
        <h2>Registrar venta</h2>
        <form method="post" action="index.php">
            <input type="hidden" name="accion" value="registrar">

            <label for="tipo">Tipo de combustible</label>
            <select name="tipo" id="tipo" required>
                <option value="">-- Seleccione --</option>
                <?php foreach (COMBUSTIBLES as $nombre => $p): ?>
                    <option value="<?= $nombre ?>"><?= $nombre ?></option>
                <?php endforeach; ?>
            </select>

            <label for="galones">Cantidad de galones</label>
            <input type="number" name="galones" id="galones" step="0.01" min="0.01" required>

            <button type="submit">Registrar</button>
        </form>
        <p class="nota">Si la cantidad supera los <?= LIMITE_SUBSIDIO ?> galones no aplica subsidio.</p>
    </section>

    <section class="tarjeta">
        <h2>Total de ventas</h2>
        <div class="resumen">
            <?php foreach ($totalesPorTipo as $nombre => $total): ?>
                <div class="dato">
                    <span><?= $nombre ?></span>
                    <strong><?= q($total) ?></strong>
                </div>
            <?php endforeach; ?>
            <div class="dato destacado">
                <span>Total general</span>
                <strong><?= q($totalGeneral) ?></strong>
            </div>
            <div class="dato">
                <span>Ventas con subsidio</span>
                <strong><?= $conSubsidio ?></strong>
            </div>
        </div>
    </section>

    <section class="tarjeta">
        <h2>Ventas registradas</h2>
        <?php if (empty($ventas)): ?>
            <p class="nota">Aún no hay ventas hoy.</p>
        <?php else: ?>
            <div class="tabla-wrap">
                <table>
                    <thead>
                    <tr>
                        <th>Combustible</th><th>Galones</th>
                        <th>Precio/gal</th><th>Subsidio</th><th>Total</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($ventas as $v): ?>
                        <tr>
                            
                            <td><?= htmlspecialchars($v['tipo']) ?></td>
                            <td><?= number_format($v['galones'], 2) ?></td>
                            <td><?= q($v['precio']) ?></td>
                            <td><span class="etiqueta <?= $v['subsidio'] === 'SI' ? 'si' : 'no' ?>"><?= $v['subsidio'] ?></span></td>
                            <td><?= q($v['total']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

        <form method="post" action="index.php" onsubmit="return confirm('¿Eliminar todos los registros?');">
            <input type="hidden" name="accion" value="limpiar">
            <button type="submit" class="peligro">Borrar todos los registros</button>
        </form>
    </section>
</main>
</body>
</html>
