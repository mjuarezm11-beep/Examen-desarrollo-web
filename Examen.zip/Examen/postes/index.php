<?php
include "conexion.php";

$mensaje = "";
$tipo = "";



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $no_poste     = trim($_POST["no_poste"]);
    $fecha        = $_POST["fecha_registro"];
    $direccion    = trim($_POST["direccion"]);
    $departamento = $_POST["departamento"];
    $municipio    = trim($_POST["municipio"]);
    $referencia   = trim($_POST["referencia"]);
    $latitud      = $_POST["latitud"];
    $longitud     = $_POST["longitud"];

    // Validaciones básicas
    if ($no_poste == "" || $fecha == "" || $direccion == "" || $municipio == "" || $referencia == "") {
        $mensaje = "Complete todos los campos.";
        $tipo = "error";
    } elseif (!is_numeric($latitud) || !is_numeric($longitud)) {
        $mensaje = "Latitud y longitud deben ser números.";
        $tipo = "error";
    } else {
        
        $sql = "INSERT INTO postes (no_poste, fecha_registro, direccion, departamento, municipio, referencia, latitud, longitud)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ssssssdd", $no_poste, $fecha, $direccion, $departamento, $municipio, $referencia, $latitud, $longitud);
            mysqli_stmt_execute($stmt);
            
            header("Location: index.php?ok=1");
            exit;
        } catch (mysqli_sql_exception $e) {
            $mensaje = "No se pudo guardar. ¿El número de poste ya existe?";
            $tipo = "error";
        }
    }
}


$resultado = mysqli_query($conn, "SELECT * FROM postes ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Postes de alumbrado - Zacapa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    

    <div class="contenedor">

        
        <div class="caja">
            <h2>Registrar poste</h2>

            <?php if ($mensaje != ""): ?>
                <p class="mensaje <?= $tipo ?>"><?= htmlspecialchars($mensaje) ?></p>
            <?php endif; ?>

            <form method="post" class="formulario">
                <div>
                    <label>No. de poste</label>
                    <input type="text" name="no_poste" required>
                </div>

                <div>
                    <label>Fecha de registro</label>
                    <input type="date" name="fecha_registro" value="<?= date('Y-m-d') ?>" required>
                </div>

                <div class="completo">
                    <label>Dirección donde está ubicado</label>
                    <input type="text" name="direccion" required>
                </div>

                <div>
                    <label>Departamento</label>
                    <input type="text" name="departamento" value="Zacapa" readonly>
                </div>

                <div>
                    <label>Municipio</label>
                    <select name="municipio" required>
                        <option value="">-- Seleccione --</option>
                        <option>Zacapa</option>
                        <option>Estanzuela</option>
                        <option>Río Hondo</option>
                        <option>Gualán</option>
                        <option>Teculután</option>
                        <option>Usumatlán</option>
                        <option>Cabañas</option>
                        <option>San Diego</option>
                        <option>La Unión</option>
                        <option>Huité</option>
                        <option>San Jorge</option>
                    </select>
                </div>

                <div class="completo">
                    <label>Referencia</label>
                    <input type="text" name="referencia" required>
                </div>

                <div>
                    <label>Latitud</label>
                    <input type="text" name="latitud" placeholder="14.9723" required>
                </div>

                <div>
                    <label>Longitud</label>
                    <input type="text" name="longitud" placeholder="-89.5339" required>
                </div>

                <div class="completo">
                    <button type="submit">Guardar</button>
                </div>
            </form>
        </div>


        <div class="caja">
            <h2>Postes ingresados (<?= mysqli_num_rows($resultado) ?>)</h2>

            <div class="tabla-wrap">
            <table>
                <tr>
                    <th>No. poste</th>
                    <th>Fecha</th>
                    <th>Dirección</th>
                    <th>Departamento</th>
                    <th>Municipio</th>
                    <th>Referencia</th>
                    <th>Latitud</th>
                    <th>Longitud</th>
                </tr>
                <?php while ($fila = mysqli_fetch_assoc($resultado)): ?>
                <tr>
                    <td><?= htmlspecialchars($fila["no_poste"]) ?></td>
                    <td><?= $fila["fecha_registro"] ?></td>
                    <td><?= htmlspecialchars($fila["direccion"]) ?></td>
                    <td><?= htmlspecialchars($fila["departamento"]) ?></td>
                    <td><?= htmlspecialchars($fila["municipio"]) ?></td>
                    <td><?= htmlspecialchars($fila["referencia"]) ?></td>
                    <td><?= $fila["latitud"] ?></td>
                    <td><?= $fila["longitud"] ?></td>
                </tr>
                <?php endwhile; ?>
            </table>
            </div>

            <?php if (mysqli_num_rows($resultado) == 0): ?>
                <p>No hay postes registrados.</p>
            <?php endif; ?>
        </div>

    </div>
</body>
</html>
