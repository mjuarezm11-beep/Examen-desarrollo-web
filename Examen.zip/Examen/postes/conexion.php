<?php

$conn = mysqli_connect("localhost", "root", "Michelle123", "alumbrado_zacapa");

if (!$conn) {
    die("Error de conexión: " . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8mb4");
