CREATE DATABASE IF NOT EXISTS alumbrado_zacapa;
USE alumbrado_zacapa;

CREATE TABLE IF NOT EXISTS postes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    no_poste VARCHAR(20) NOT NULL UNIQUE,
    fecha_registro DATE NOT NULL,
    direccion VARCHAR(200) NOT NULL,
    departamento VARCHAR(50) NOT NULL,
    municipio VARCHAR(50) NOT NULL,
    referencia VARCHAR(200) NOT NULL,
    latitud DECIMAL(10,7) NOT NULL,
    longitud DECIMAL(10,7) NOT NULL
);
